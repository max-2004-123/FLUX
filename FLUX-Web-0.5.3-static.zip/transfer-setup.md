# FLUX 私人設備互傳

桌面版 0.7.0／網頁版 0.5.0。首次設定需要在 Google 完成授權，程式不會替你登入。

## 更新現有 Apps Script

1. 用同一個 Google 帳號打開目前 FLUX 的 Apps Script 專案。
2. 將本資料夾的 `Code.gs` 完整覆蓋至專案，保留原本指令碼屬性中的 SYNC_TOKEN、SPREADSHEET_ID、CALENDAR_ID。
3. 專案設定 → 顯示 appsscript.json 資訊清單，將本資料夾的 `appsscript.json` 內容貼入。保留 Google Calendar 服務；新增的權限是 Drive `drive.file` 與對外連線。
4. 在服務加入 Google Drive API v3（使用標準 Cloud 專案時，也在該專案的 API 程式庫啟用 Google Drive API）。
5. 在函式下拉選單選 `authorizeTransfers`，執行並授權。首次會建立私人「FLUX 中轉站」資料夾，並自動儲存 TRANSFER_FOLDER_ID。再次執行只檢查現有資料夾。
6. 部署 → 管理部署作業 → 編輯 → 版本選「新版本」→ 部署。執行身分使用「我」，存取對象使用「所有人」；每一個清單／上傳請求仍會先驗證 SYNC_TOKEN。請勿把密語放進 GitHub。
7. 電腦和手機填入相同 `/exec` 網址與同步密語，開啟「互傳」後按重新整理。

## 使用

- 電腦：主畫面右上「互傳」，或輸入泡泡的「互傳 ↗」。拖入檔案或按「選擇檔案」。
- iPhone：打開網頁版右上「互傳」，選擇照片或檔案。
- 同時可排入 10 個待傳檔案，逐個上傳；單檔 1 byte～20 GB，實際仍受 Drive 剩餘空間及服務配額限制。
- 每次只傳 8 MB；暫停或連線失敗後按「繼續」，會先詢問 Google 已收到的位元組，再接著傳。頁面／App 關閉後不保存上傳工作，需重新選檔；已完成的檔案不受影響。
- 手機上傳時保持頁面開啟與螢幕解鎖。iOS 切換 App、鎖屏或系統回收頁面可能中斷傳送，不保證背景上傳。
- 清單在互傳視窗開啟且頁面可見時每 30 秒更新，也可手動重新整理。
- 「開啟／下載」會交由 Google Drive；請登入建立中轉站的同一個 Google 帳號，大檔可能顯示 Google 的下載確認。
- 不自動刪檔，不公開分享。需清理時，請到自己的 Drive 操作。

## 權限及資料

此版本使用 `drive.file`，清單只查詢 App 建立的中轉站資料夾、且帶有 FLUX 互傳標記的檔案，不是整個 Drive 瀏覽器。不要把其他資料夾 ID 手動填入 TRANSFER_FOLDER_ID。

Apps Script 持有 Google OAuth 憑證，客戶端只取得單次上傳連線，不會取得 OAuth token。上傳連線同樣屬敏感資訊，只保留在記憶體，勿分享或記錄。檔案本體直接傳到 Google Drive，不經 Gemini，也不寫進 Sheets。

若清單提示「同步請求格式不正確」，表示仍使用舊部署。若 HTTP 403，請檢查 Drive API、資訊清單權限並重新執行 authorizeTransfers 授權。Apps Script 部署更新後網址通常不變。

## 驗證範圍

本機包含模擬 Google 回應的分段續傳、安全驗證及桌面／手機版面測試。實際跨設備傳檔仍須完成上述 Google 授權與部署後驗證；沒有預設金鑰、公開測試帳號或實際雲端測試檔。
